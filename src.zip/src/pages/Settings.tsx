import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Switch } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

export default function Settings({ navigation }: any) {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [pushEnabled, setPushEnabled] = useState(true);
  const [emailEnabled, setEmailEnabled] = useState(false);

  // Reusable row component for the settings toggles
  const SettingRow = ({ label, value, onValueChange, isLast = false }: any) => (
    <View style={[styles.settingRow, isLast && { borderBottomWidth: 0 }]}>
      <Text style={styles.settingLabel}>{label}</Text>
      <Switch
        trackColor={{ false: theme.colors.bgInput, true: theme.colors.accentColor }}
        thumbColor={'#ffffff'}
        ios_backgroundColor={theme.colors.bgInput}
        onValueChange={onValueChange}
        value={value}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.innerHeader}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={theme.colors.textMain} />
          </TouchableOpacity>
          <Text style={styles.pageTitle}>Settings</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.contentPadding}>
        {/* Appearance Section */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>APPEARANCE</Text>
          <SettingRow 
            label="Dark Mode (Off for Light)" 
            value={isDarkMode} 
            onValueChange={setIsDarkMode} 
            isLast={true}
          />
        </View>

        {/* Notifications Section */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>NOTIFICATIONS</Text>
          <SettingRow 
            label="Push Notifications" 
            value={pushEnabled} 
            onValueChange={setPushEnabled} 
          />
          <SettingRow 
            label="Email Updates" 
            value={emailEnabled} 
            onValueChange={setEmailEnabled} 
            isLast={true}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  innerHeader: { padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  headerLeft: { flexDirection: 'row', alignItems: 'center' },
  backButton: { marginRight: 15 },
  pageTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1, textTransform: 'uppercase' },
  contentPadding: { padding: 20, paddingBottom: 100 },
  
  card: { backgroundColor: theme.colors.bgCard, padding: 20, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: theme.colors.borderColor },
  sectionTitle: { color: theme.colors.textMuted, fontSize: 12, marginBottom: 15, fontWeight: '600', letterSpacing: 1 },
  
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  settingLabel: { color: theme.colors.textMain, fontSize: 15 },
});
