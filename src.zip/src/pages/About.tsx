import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, LayoutAnimation, Platform, UIManager } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

// 1. Enable LayoutAnimation for Android
// iOS enables this by default, but Android requires this explicit opt-in
if (Platform.OS === 'android') {
  if (UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
  }
}

// 2. Reusable Accordion Item Component
const AccordionItem = ({ title, content }: { title: string, content: string }) => {
  const [expanded, setExpanded] = useState(false);

  const toggleExpand = () => {
    // This tells React Native to animate the next state change
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpanded(!expanded);
  };

  return (
    <View style={styles.accordionItem}>
      <TouchableOpacity 
        style={styles.accordionHeader} 
        onPress={toggleExpand} 
        activeOpacity={0.7}
      >
        <Text style={styles.accordionTitle}>{title}</Text>
        <Ionicons 
          name={expanded ? "chevron-up" : "chevron-down"} 
          size={20} 
          color={theme.colors.textMain} 
        />
      </TouchableOpacity>
      
      {/* Conditionally render the content. LayoutAnimation handles the smooth reveal. */}
      {expanded && (
        <View style={styles.accordionContent}>
          <Text style={styles.accordionText}>{content}</Text>
        </View>
      )}
    </View>
  );
};

// 3. Main Page Component
export default function About() {
  return (
    <View style={styles.container}>
      {/* Inner Header */}
      <View style={styles.innerHeader}>
        <Text style={styles.pageTitle}>About Us</Text>
      </View>

      <ScrollView contentContainerStyle={styles.contentPadding}>
        {/* Note: React Native Image doesn't support CSS grayscale filters out of the box, 
            so we add a dark overlay view on top of the image to mimic a muted feel. */}
        <View style={styles.imageContainer}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1438232992991-995b7058bbb3?q=80&w=2073' }} 
            style={styles.heroImage} 
          />
          <View style={styles.imageOverlay} />
        </View>
        
        {/* Accordion List */}
        <AccordionItem 
          title="Our Mission" 
          content="We exist to lead people into a growing relationship with Jesus Christ through worship, community, and service." 
        />
        <AccordionItem 
          title="Service Times" 
          content={`Sundays:\n9:00 AM & 11:00 AM\n\nWednesdays:\n7:00 PM (Youth & Kids)`} 
        />
        <AccordionItem 
          title="Contact Us" 
          content={`123 Worship Street, Cityville\nPhone: (555) 123-4567`} 
        />
      </ScrollView>
    </View>
  );
}

// 4. Styles
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  
  // Header
  innerHeader: { padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  pageTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1, textTransform: 'uppercase' },
  contentPadding: { padding: 20, paddingBottom: 100 },
  
  // Hero Image
  imageContainer: { width: '100%', height: 180, marginBottom: 20, borderRadius: 8, overflow: 'hidden', position: 'relative' },
  heroImage: { width: '100%', height: '100%', objectFit: 'cover' },
  imageOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)' },
  
  // Accordion
  accordionItem: { borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  accordionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 20 },
  accordionTitle: { color: theme.colors.textMain, fontSize: 15, fontWeight: '500' },
  accordionContent: { paddingBottom: 20, overflow: 'hidden' },
  accordionText: { color: theme.colors.textMuted, fontSize: 13, lineHeight: 22 },
});