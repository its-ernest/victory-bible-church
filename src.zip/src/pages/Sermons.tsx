import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

export default function Sermons({ navigation }: any) {
  return (
    <View style={styles.container}>
      <View style={styles.innerHeader}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={theme.colors.textMain} />
          </TouchableOpacity>
          <Text style={styles.pageTitle}>Sermons</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.contentPadding}>
        {/* Video Sermon Card */}
        <View style={styles.card}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1478737270239-2f02b77ac6d5?auto=format&fit=crop&q=80&w=600' }} 
            style={styles.cardImage} 
          />
          <Text style={styles.cardTitle}>Finding Peace in Chaos</Text>
          <Text style={styles.cardMeta}>Pastor John • Sunday Service</Text>
          <TouchableOpacity style={styles.btnMain} activeOpacity={0.8}>
            <Ionicons name="play" size={16} color="black" style={styles.btnIcon} />
            <Text style={styles.btnText}>Watch Now</Text>
          </TouchableOpacity>
        </View>

        {/* Audio Sermon Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>The Power of Community</Text>
          <Text style={styles.cardMeta}>Audio Series • Part 3</Text>
          <TouchableOpacity style={[styles.btnMain, styles.btnDark]} activeOpacity={0.8}>
            <Ionicons name="headset" size={16} color="white" style={styles.btnIcon} />
            <Text style={[styles.btnText, { color: 'white' }]}>Listen</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  innerHeader: { padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  headerLeft: { flexDirection: 'row', alignItems: 'center' },
  backButton: { marginRight: 15 },
  pageTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1, textTransform: 'uppercase' },
  contentPadding: { padding: 20, paddingBottom: 100 },
  
  card: { backgroundColor: theme.colors.bgCard, padding: 20, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: theme.colors.borderColor },
  cardImage: { width: '100%', height: 160, borderRadius: 6, marginBottom: 12, objectFit: 'cover' },
  cardTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '600' },
  cardMeta: { color: theme.colors.textMuted, fontSize: 12, marginTop: 5 },
  
  btnMain: { backgroundColor: 'white', flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 14, borderRadius: 6, marginTop: 15, borderWidth: 1, borderColor: theme.colors.borderColor },
  btnDark: { backgroundColor: '#333', borderColor: '#333' },
  btnIcon: { marginRight: 8 },
  btnText: { color: 'black', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 1, fontSize: 14 },
});