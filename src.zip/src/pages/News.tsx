import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

// 1. Initial Mock Data
const INITIAL_FEED = [
  { 
    id: '1', 
    author: 'Worship Team', 
    initial: 'W', 
    time: '2 hours ago', 
    text: 'What an incredible night of worship! Thanks to everyone who came out. 🙌', 
    image: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?q=80&w=2070', 
    isLiked: false 
  },
  { 
    id: '2', 
    author: 'Youth Group', 
    initial: 'Y', 
    time: 'Yesterday', 
    text: "Don't forget signups for Summer Camp close this Friday! Link in bio.", 
    image: null, 
    isLiked: false 
  }
];

// 2. Individual Card Component (Handles its own animation)
const NewsCard = ({ post, onToggleLike }: any) => {
  // Animation value for the heart icon
  const scaleValue = useRef(new Animated.Value(1)).current;

  const handleLikePress = () => {
    // 1. Toggle the state in the parent
    onToggleLike(post.id);

    // 2. Run the "Pop" animation if it's being liked (not unliked)
    if (!post.isLiked) {
      Animated.sequence([
        Animated.timing(scaleValue, { toValue: 1.4, duration: 150, useNativeDriver: true }),
        Animated.timing(scaleValue, { toValue: 1, duration: 150, useNativeDriver: true })
      ]).start();
    }
  };

  return (
    <View style={styles.card}>
      {/* Header: Avatar and Meta */}
      <View style={styles.newsHeader}>
        <View style={styles.newsAvatar}>
          <Text style={styles.avatarText}>{post.initial}</Text>
        </View>
        <View style={styles.newsMeta}>
          <Text style={styles.authorName}>{post.author}</Text>
          <Text style={styles.postTime}>{post.time}</Text>
        </View>
      </View>

      {/* Content: Text and Optional Image */}
      <Text style={styles.postText}>{post.text}</Text>
      {post.image && (
        <Image source={{ uri: post.image }} style={styles.newsImg} />
      )}

      {/* Actions: Like, Comment, Share */}
      <View style={styles.newsActions}>
        <TouchableOpacity onPress={handleLikePress} activeOpacity={0.7}>
          <Animated.View style={{ transform: [{ scale: scaleValue }] }}>
            <Ionicons 
              name={post.isLiked ? "heart" : "heart-outline"} 
              size={24} 
              color={post.isLiked ? theme.colors.notification : theme.colors.textMuted} 
            />
          </Animated.View>
        </TouchableOpacity>
        
        <TouchableOpacity>
          <Ionicons name="chatbubble-outline" size={22} color={theme.colors.textMuted} />
        </TouchableOpacity>
        
        <TouchableOpacity>
          <Ionicons name="share-social-outline" size={22} color={theme.colors.textMuted} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

// 3. Main Page Component
export default function News() {
  const [feed, setFeed] = useState(INITIAL_FEED);

  const toggleLike = (postId: string) => {
    setFeed(currentFeed => 
      currentFeed.map(post => 
        post.id === postId ? { ...post, isLiked: !post.isLiked } : post
      )
    );
  };

  return (
    <View style={styles.container}>
      {/* Inner Header for the Feed */}
      <View style={styles.innerHeader}>
        <Text style={styles.pageTitle}>Community Feed</Text>
      </View>

      <ScrollView contentContainerStyle={styles.contentPadding}>
        {feed.map(post => (
          <NewsCard key={post.id} post={post} onToggleLike={toggleLike} />
        ))}
      </ScrollView>
    </View>
  );
}

// 4. Styles
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  
  // Inner Header
  innerHeader: { padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  pageTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1, textTransform: 'uppercase' },
  contentPadding: { padding: 20, paddingBottom: 100 },
  
  // Card Styles
  card: { backgroundColor: theme.colors.bgCard, padding: 20, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: theme.colors.borderColor },
  newsHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  newsAvatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: theme.colors.bgInput, borderWidth: 1, borderColor: theme.colors.borderColor, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  avatarText: { color: theme.colors.textMain, fontWeight: 'bold', fontSize: 16 },
  newsMeta: { flex: 1 },
  authorName: { color: theme.colors.textMain, fontSize: 14, fontWeight: '600' },
  postTime: { color: theme.colors.textMuted, fontSize: 11, marginTop: 2 },
  postText: { color: theme.colors.textMain, fontSize: 14, lineHeight: 21, marginBottom: 15 },
  newsImg: { width: '100%', height: 200, borderRadius: 8, marginBottom: 15 },
  
  // Actions
  newsActions: { flexDirection: 'row', gap: 20, marginTop: 5, alignItems: 'center' }
});