import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, ImageBackground } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

// Mock data for the recent videos list
const RECENT_VIDEOS = [
  {
    id: '1',
    title: 'Faith in Action',
    meta: '2 days ago • 45 min',
    thumb: 'https://images.unsplash.com/photo-1519834785169-98be25ec3f84?q=80&w=400'
  },
  {
    id: '2',
    title: 'The Art of Prayer',
    meta: '1 week ago • 52 min',
    thumb: 'https://images.unsplash.com/photo-1507643179173-617d654f3daf?q=80&w=400'
  }
];

export default function Video() {
  return (
    <View style={styles.container}>
      {/* Inner Header */}
      <View style={styles.innerHeader}>
        <Text style={styles.pageTitle}>Watch Live</Text>
      </View>

      {/* Main Video Player Placeholder */}
      <View style={styles.videoPlayer}>
        <ImageBackground 
          source={{ uri: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?q=80&w=800' }} 
          style={styles.videoBg}
          imageStyle={{ opacity: 0.4 }} // Darkens the background image
        >
          {/* Live Badge */}
          <View style={styles.liveBadge}>
            <Text style={styles.liveBadgeText}>LIVE NOW</Text>
          </View>

          {/* Centered Play Button & Title */}
          <TouchableOpacity style={styles.playCenter} activeOpacity={0.7}>
            <Ionicons name="play-circle" size={60} color="white" style={{ opacity: 0.9 }} />
            <Text style={styles.playText}>SUNDAY MORNING SERVICE</Text>
          </TouchableOpacity>
        </ImageBackground>
      </View>

      {/* Recent Messages List */}
      <ScrollView contentContainerStyle={styles.contentPadding}>
        <Text style={styles.sectionHeading}>Recent Messages</Text>
        
        {RECENT_VIDEOS.map(video => (
          <TouchableOpacity key={video.id} style={styles.videoListItem} activeOpacity={0.7}>
            <Image source={{ uri: video.thumb }} style={styles.videoThumb} />
            <View style={styles.videoInfo}>
              <Text style={styles.videoTitle}>{video.title}</Text>
              <Text style={styles.videoMeta}>{video.meta}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

// Styles
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  
  // Header
  innerHeader: { padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  pageTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1, textTransform: 'uppercase' },
  
  // Video Player
  videoPlayer: { width: '100%', height: 220, backgroundColor: '#000' },
  videoBg: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  liveBadge: { position: 'absolute', top: 15, left: 15, backgroundColor: theme.colors.notification, paddingVertical: 4, paddingHorizontal: 8, borderRadius: 3 },
  liveBadgeText: { color: 'white', fontSize: 10, fontWeight: '700', textTransform: 'uppercase' },
  playCenter: { alignItems: 'center', zIndex: 5 },
  playText: { color: 'white', marginTop: 10, fontSize: 12, letterSpacing: 1 },
  
  // Recent Messages List
  contentPadding: { padding: 20, paddingBottom: 100 },
  sectionHeading: { color: theme.colors.textMain, fontSize: 16, marginBottom: 20, paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  videoListItem: { flexDirection: 'row', gap: 15, marginBottom: 20 },
  videoThumb: { width: 100, height: 60, backgroundColor: '#333', borderRadius: 4 },
  videoInfo: { flex: 1, justifyContent: 'center' },
  videoTitle: { color: theme.colors.textMain, fontWeight: '500', fontSize: 14, marginBottom: 4 },
  videoMeta: { color: theme.colors.textMuted, fontSize: 11 },
});