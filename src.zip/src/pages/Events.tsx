import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

export default function Events({ navigation }: any) {
  return (
    <View style={styles.container}>
      <View style={styles.innerHeader}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={theme.colors.textMain} />
          </TouchableOpacity>
          <Text style={styles.pageTitle}>Upcoming</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.contentPadding}>
        {/* Event Card 1 */}
        <View style={styles.card}>
          <Text style={styles.dateLabel}>DEC 24 • 6:00 PM</Text>
          <Text style={styles.eventTitle}>Christmas Eve Service</Text>
          <Text style={styles.eventDesc}>Join us for a night of carols and candlelight.</Text>
          <TouchableOpacity style={styles.btnMain} activeOpacity={0.8}>
            <Text style={styles.btnText}>RSVP</Text>
          </TouchableOpacity>
        </View>

        {/* Event Card 2 */}
        <View style={styles.card}>
          <Text style={styles.dateLabel}>JAN 10 • 7:00 PM</Text>
          <Text style={styles.eventTitle}>Youth Night</Text>
          <Text style={styles.eventDesc}>Games, food, and worship for ages 13-18.</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  innerHeader: { padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  headerLeft: { flexDirection: 'row', alignItems: 'center' },
  backButton: { marginRight: 15 },
  pageTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1, textTransform: 'uppercase' },
  contentPadding: { padding: 20, paddingBottom: 100 },
  
  card: { backgroundColor: theme.colors.bgCard, padding: 20, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: theme.colors.borderColor },
  dateLabel: { color: '#d4af37', fontSize: 12, fontWeight: 'bold', marginBottom: 5 },
  eventTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '600' },
  eventDesc: { color: theme.colors.textMuted, fontSize: 13, marginVertical: 5 },
  
  btnMain: { backgroundColor: 'white', padding: 14, borderRadius: 6, alignItems: 'center', marginTop: 15, borderWidth: 1, borderColor: theme.colors.borderColor },
  btnText: { color: 'black', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 1, fontSize: 14 },
});