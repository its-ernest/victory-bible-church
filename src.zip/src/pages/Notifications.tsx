import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

const INITIAL_NOTIFICATIONS = [
  { id: '1', title: 'Donation Successful', desc: 'Thank you! Your donation of $50.00 was successfully processed.', time: '2 mins ago', icon: 'heart', color: '#e74c3c', isRead: false },
  { id: '2', title: 'Event Reminder', desc: "Youth Night starts in 1 hour. Don't forget your ticket!", time: '1 hour ago', icon: 'calendar', color: '#3498db', isRead: false },
  { id: '3', title: 'New Comment', desc: 'Sarah replied to your comment on the Community Feed.', time: '3 hours ago', icon: 'chatbubble', color: '#f1c40f', isRead: false },
  { id: '4', title: 'Sunday Service is Live', desc: 'Join us online for worship.', time: 'Yesterday', icon: 'videocam', color: '#555', isRead: true },
];

export default function Notifications({ navigation }: any) {
  const [notifications, setNotifications] = useState(INITIAL_NOTIFICATIONS);

  const markAllRead = () => {
    const updated = notifications.map(notif => ({ ...notif, isRead: true }));
    setNotifications(updated);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={theme.colors.textMain} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>INBOX</Text>
        </View>
        <TouchableOpacity onPress={markAllRead}>
          <Ionicons name="checkmark-done-outline" size={24} color={theme.colors.textMuted} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.listContainer}>
        {notifications.map((item, index) => (
          <TouchableOpacity 
            key={item.id} 
            style={[
              styles.notifItem, 
              !item.isRead && styles.notifItemUnread,
              index === 0 && { borderTopLeftRadius: 12, borderTopRightRadius: 12 },
              index === notifications.length - 1 && { borderBottomLeftRadius: 12, borderBottomRightRadius: 12, borderBottomWidth: 0 }
            ]}
          >
            <View style={[styles.iconContainer, { backgroundColor: item.isRead ? '#333' : item.color }]}>
              <Ionicons name={item.icon as any} size={16} color={item.isRead ? '#aaa' : 'white'} />
            </View>
            <View style={styles.textContent}>
              <Text style={styles.notifTitle}>{item.title}</Text>
              <Text style={styles.notifDesc}>{item.desc}</Text>
              <Text style={styles.notifTime}>{item.time}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  headerLeft: { flexDirection: 'row', alignItems: 'center' },
  backButton: { marginRight: 15 },
  headerTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1 },
  listContainer: { padding: 20 },
  notifItem: { flexDirection: 'row', padding: 15, backgroundColor: theme.colors.bgCard, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  notifItemUnread: { backgroundColor: theme.colors.bgInput, borderLeftWidth: 3, borderLeftColor: theme.colors.notification },
  iconContainer: { width: 35, height: 35, borderRadius: 17.5, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  textContent: { flex: 1 },
  notifTitle: { color: theme.colors.textMain, fontSize: 14, fontWeight: '600', marginBottom: 4 },
  notifDesc: { color: theme.colors.textMuted, fontSize: 12, lineHeight: 18 },
  notifTime: { color: theme.colors.textMuted, fontSize: 10, marginTop: 5 }
});