import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground, Dimensions } from 'react-native';
import { theme } from '../styles/theme';
import Button from '../components/common/Button'; // Using our new global button

const { width } = Dimensions.get('window');

export default function Login({ navigation }: any) {
  // 1. Logic States: 'insight' | 'phone' | 'otp'
  const [step, setStep] = useState<'insight' | 'phone' | 'otp'>('insight');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');

  const handleVerifyOtp = () => {
    if (otp === '123456') {
      // In a real app, you'd save 'hasRegistered: true' to AsyncStorage here
      navigation.replace('MainApp');
    } else {
      alert('Invalid Code. Hint: 123456');
    }
  };

  return (
    <ImageBackground 
      source={{ uri: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?q=80&w=2070' }} 
      style={styles.container}
    >
      <View style={styles.overlay}>
        
        {/* --- STEP 1: FELLOWSHIP INSIGHT --- */}
        {step === 'insight' && (
          <View style={styles.innerContent}>
            <View style={styles.logo}><Text style={styles.logoText}>V</Text></View>
            <Text style={styles.title}>Victory Bible Church</Text>
            <Text style={styles.insightText}>
              Join a community of believers dedicated to worship, growth, and impacting lives. 
              Our fellowship provides a home for your spiritual journey.
            </Text>
            <View style={styles.bulletPoint}>
              <Text style={styles.bullet}>•</Text>
              <Text style={styles.bulletText}>Weekly transformational messages</Text>
            </View>
            <View style={styles.bulletPoint}>
              <Text style={styles.bullet}>•</Text>
              <Text style={styles.bulletText}>Supportive local community groups</Text>
            </View>
            <Button title="Join the Fellowship" onPress={() => setStep('phone')} />
          </View>
        )}

        {/* --- STEP 2: PHONE ENTRY --- */}
        {step === 'phone' && (
          <View style={styles.innerContent}>
            <Text style={styles.title}>Your Phone</Text>
            <Text style={styles.subtitle}>Enter your number to get started</Text>
            <TextInput 
              style={styles.input} 
              placeholder="e.g. +233 24 000 0000" 
              placeholderTextColor={theme.colors.textMuted}
              keyboardType="phone-pad"
              value={phoneNumber}
              onChangeText={setPhoneNumber}
              autoFocus
            />
            <Button title="Send Code" onPress={() => setStep('otp')} disabled={!phoneNumber} />
            <TouchableOpacity onPress={() => setStep('insight')}>
              <Text style={styles.backLink}>Back</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* --- STEP 3: OTP ENTRY --- */}
        {step === 'otp' && (
          <View style={styles.innerContent}>
            <Text style={styles.title}>Verify Code</Text>
            <Text style={styles.subtitle}>We sent a code to {phoneNumber}</Text>
            <TextInput 
              style={styles.input} 
              placeholder="Enter 6-digit code" 
              placeholderTextColor={theme.colors.textMuted}
              keyboardType="number-pad"
              maxLength={6}
              value={otp}
              onChangeText={setOtp}
              autoFocus
            />
            <Button title="Confirm & Login" onPress={handleVerifyOtp} />
            <TouchableOpacity onPress={() => setStep('phone')}>
              <Text style={styles.backLink}>Edit Phone Number</Text>
            </TouchableOpacity>
          </View>
        )}

      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  overlay: { 
    ...StyleSheet.absoluteFillObject, 
    backgroundColor: 'rgba(0,0,0,0.85)', 
    padding: 30, 
    justifyContent: 'center' 
  },
  innerContent: { width: '100%', alignItems: 'center' },
  logo: { 
    width: 80, height: 80, borderRadius: 40, borderWidth: 2, 
    borderColor: 'white', justifyContent: 'center', alignItems: 'center', marginBottom: 20 
  },
  logoText: { color: 'white', fontSize: 40, fontWeight: '300' },
  title: { color: 'white', fontSize: 28, fontWeight: '600', marginBottom: 10, textAlign: 'center' },
  subtitle: { color: theme.colors.textMuted, fontSize: 16, marginBottom: 30, textAlign: 'center' },
  
  // Insight Specific Styles
  insightText: { 
    color: 'white', fontSize: 16, textAlign: 'center', 
    lineHeight: 24, marginBottom: 25, opacity: 0.9 
  },
  bulletPoint: { flexDirection: 'row', alignSelf: 'flex-start', marginBottom: 10, paddingHorizontal: 20 },
  bullet: { color: theme.colors.accentColor, fontSize: 18, marginRight: 10 },
  bulletText: { color: 'white', fontSize: 15 },

  input: { 
    width: '100%', backgroundColor: 'rgba(255,255,255,0.1)', 
    borderColor: 'rgba(255,255,255,0.2)', borderWidth: 1, 
    color: 'white', padding: 18, borderRadius: 8, fontSize: 18, 
    marginBottom: 20, textAlign: 'center' 
  },
  backLink: { color: theme.colors.textMuted, marginTop: 20, fontSize: 14, textDecorationLine: 'underline' }
});