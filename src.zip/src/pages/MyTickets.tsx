import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

export default function MyTickets({ navigation }: any) {
  return (
    <View style={styles.container}>
      {/* Inner Header */}
      <View style={styles.innerHeader}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={theme.colors.textMain} />
          </TouchableOpacity>
          <Text style={styles.pageTitle}>My Tickets</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.contentPadding}>
        {/* Ticket Card */}
        <View style={styles.ticketCard}>
          <View style={styles.ticketHeader}>
            <View>
              <Text style={styles.eventTitle}>Christmas Eve</Text>
              <Text style={styles.eventMeta}>DEC 24 • 6:00 PM</Text>
            </View>
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>CONFIRMED</Text>
            </View>
          </View>
          
          {/* Mock QR Code Section */}
          <View style={styles.qrBox}>
            <Ionicons name="qr-code" size={40} color="black" style={{ marginRight: 10 }} />
            <Text style={styles.qrText}>SCAN ME</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  
  // Header
  innerHeader: { padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  headerLeft: { flexDirection: 'row', alignItems: 'center' },
  backButton: { marginRight: 15 },
  pageTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1, textTransform: 'uppercase' },
  contentPadding: { padding: 20, paddingBottom: 100 },
  
  // Ticket Card
  ticketCard: { 
    backgroundColor: theme.colors.bgCard, 
    padding: 20, 
    borderRadius: 12, 
    borderWidth: 1, 
    borderColor: theme.colors.borderColor,
    borderLeftWidth: 4, 
    borderLeftColor: theme.colors.accentColor 
  },
  ticketHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  eventTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '600' },
  eventMeta: { color: theme.colors.textMuted, fontSize: 12, marginTop: 5 },
  
  statusBadge: { backgroundColor: theme.colors.accentColor, paddingVertical: 5, paddingHorizontal: 10, borderRadius: 4, alignSelf: 'flex-start' },
  statusText: { color: 'white', fontSize: 10, fontWeight: 'bold', letterSpacing: 0.5 },
  
  // QR Box
  qrBox: { 
    width: '100%', 
    height: 120, 
    backgroundColor: 'white', 
    marginTop: 20, 
    borderRadius: 8, 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center' 
  },
  qrText: { color: 'black', fontWeight: 'bold', fontSize: 16, letterSpacing: 1 }
});