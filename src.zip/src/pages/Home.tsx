import React from 'react';
import { View, Text, StyleSheet, ImageBackground, TouchableOpacity } from 'react-native';
import { theme } from '../styles/theme';

const SECTIONS = [
  { id: 'Sermons', title: 'SERMONS', image: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?q=80&w=2070' },
  { id: 'Events', title: 'EVENTS', image: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?q=80&w=2070' },
  { id: 'Give', title: 'GIVE', image: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=2032' },
];

export default function Home({ navigation }: any) {
  return (
    <View style={styles.container}>
      {SECTIONS.map((section) => (
        <TouchableOpacity 
          key={section.id} 
          style={styles.section} 
          activeOpacity={0.8}
          onPress={() => navigation.navigate(section.id)}
        >
          <ImageBackground source={{ uri: section.image }} style={styles.bgImg}>
            <View style={styles.overlay} />
            <Text style={styles.title}>{section.title}</Text>
          </ImageBackground>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  section: { flex: 1, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  bgImg: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.5)' },
  title: { color: 'white', fontSize: 36, fontWeight: '200', letterSpacing: 4, zIndex: 1 },
});