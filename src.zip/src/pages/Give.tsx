import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

export default function Give({ navigation }: any) {
  const [amount, setAmount] = useState('');

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={theme.colors.textMain} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>GIVE</Text>
        <View style={{ width: 24 }} /> {/* Spacer to center the title */}
      </View>

      <View style={styles.content}>
        <View style={styles.donateCard}>
          <View style={styles.inputContainer}>
            <Text style={styles.currencySymbol}>$</Text>
            <TextInput
              style={styles.amountInput}
              placeholder="0.00"
              placeholderTextColor={theme.colors.textMuted}
              keyboardType="decimal-pad"
              value={amount}
              onChangeText={setAmount}
              maxLength={8}
            />
          </View>
          <Text style={styles.helperText}>Tap to enter amount</Text>
          
          <TouchableOpacity style={styles.donateButton}>
            <Text style={styles.donateButtonText}>Donate Now</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.historyCard}>
          <Text style={styles.historyTitle}>Your Giving History</Text>
          <Text style={styles.historyDesc}>View your past tithes and offerings.</Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  backButton: { padding: 5 },
  headerTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1 },
  content: { padding: 20 },
  donateCard: { backgroundColor: theme.colors.bgCard, padding: 40, borderRadius: 12, alignItems: 'center', marginBottom: 20, borderWidth: 1, borderColor: theme.colors.borderColor },
  inputContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  currencySymbol: { color: theme.colors.textMain, fontSize: 48, fontWeight: '200', marginRight: 5 },
  amountInput: { color: theme.colors.textMain, fontSize: 48, fontWeight: '200', minWidth: 100, textAlign: 'center' },
  helperText: { color: theme.colors.textMuted, marginTop: 10, marginBottom: 20 },
  donateButton: { backgroundColor: 'white', width: '100%', padding: 15, borderRadius: 6, alignItems: 'center' },
  donateButtonText: { color: 'black', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 1 },
  historyCard: { backgroundColor: theme.colors.bgCard, padding: 20, borderRadius: 12, borderWidth: 1, borderColor: theme.colors.borderColor },
  historyTitle: { color: theme.colors.textMain, fontSize: 16, fontWeight: '600', marginBottom: 5 },
  historyDesc: { color: theme.colors.textMuted, fontSize: 13 }
});