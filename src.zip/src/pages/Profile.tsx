import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Image, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../styles/theme';

export default function Profile({ navigation }: any) {
  const [name, setName] = useState('James Wilson');
  const [email, setEmail] = useState('james@example.com');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  const handleSave = () => {
    setSaveStatus('saving');
    setTimeout(() => {
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    }, 800);
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ padding: 5 }}>
          <Ionicons name="arrow-back" size={24} color={theme.colors.textMain} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>MY PROFILE</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.avatarSection}>
          <Image source={{ uri: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200' }} style={styles.profileImg} />
          <Text style={styles.nameText}>{name}</Text>
          <Text style={styles.memberText}>Member since 2023</Text>
        </View>

        <View style={styles.card}>
          <View style={styles.formGroup}>
            <Text style={styles.label}>Full Name</Text>
            <TextInput style={styles.input} value={name} onChangeText={setName} placeholderTextColor={theme.colors.textMuted} />
          </View>
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput style={styles.input} value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
          </View>

          <TouchableOpacity 
            style={[
              styles.btnMain, 
              saveStatus === 'saving' && { backgroundColor: '#ccc', borderColor: '#ccc' },
              saveStatus === 'saved' && { backgroundColor: theme.colors.accentColor, borderColor: theme.colors.accentColor }
            ]} 
            onPress={handleSave}
            disabled={saveStatus !== 'idle'}
          >
            <Text style={[styles.btnText, saveStatus === 'saved' && { color: 'white' }]}>
              {saveStatus === 'idle' ? 'Save Changes' : saveStatus === 'saving' ? 'Saving...' : 'Saved!'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.bgApp },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  headerTitle: { color: theme.colors.textMain, fontSize: 18, fontWeight: '500', letterSpacing: 1 },
  content: { padding: 20 },
  avatarSection: { alignItems: 'center', marginBottom: 30 },
  profileImg: { width: 100, height: 100, borderRadius: 50, borderWidth: 2, borderColor: theme.colors.borderColor, marginBottom: 15 },
  nameText: { color: theme.colors.textMain, fontSize: 22, fontWeight: '600', marginBottom: 5 },
  memberText: { color: theme.colors.textMuted, fontSize: 12 },
  card: { backgroundColor: theme.colors.bgCard, padding: 20, borderRadius: 12, borderWidth: 1, borderColor: theme.colors.borderColor },
  formGroup: { marginBottom: 15 },
  label: { color: theme.colors.textMuted, fontSize: 11, textTransform: 'uppercase', marginBottom: 5 },
  input: { backgroundColor: theme.colors.bgInput, borderWidth: 1, borderColor: theme.colors.borderColor, color: theme.colors.textMain, padding: 12, borderRadius: 6, fontSize: 14 },
  btnMain: { backgroundColor: 'white', padding: 14, borderRadius: 6, alignItems: 'center', marginTop: 15, borderWidth: 1, borderColor: theme.colors.borderColor },
  btnText: { color: 'black', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 1 },
});