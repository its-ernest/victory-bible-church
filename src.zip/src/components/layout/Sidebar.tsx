import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { DrawerContentScrollView, DrawerContentComponentProps } from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { theme } from '../../styles/theme';

// 1. Strict TypeScript interface for our Menu Items
interface MenuItemProps {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  onPress: () => void;
  color?: string;
  badge?: string | number;
}

export default function Sidebar(props: DrawerContentComponentProps) {
  const { navigation } = props;
  const insets = useSafeAreaInsets(); // Grab device notches/nav bars

  // 2. Strongly typed MenuItem component
  const MenuItem = ({ icon, label, onPress, color = theme.colors.textMuted, badge }: MenuItemProps) => (
    <TouchableOpacity style={styles.menuItem} onPress={onPress}>
      <Ionicons name={icon} size={24} color={color} style={styles.icon} />
      <Text style={[styles.menuText, { color: color === theme.colors.textMuted ? theme.colors.textMain : color }]}>
        {label}
      </Text>
      {badge ? (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{badge}</Text>
        </View>
      ) : null}
    </TouchableOpacity>
  );

  return (
    <DrawerContentScrollView 
      {...props} 
      style={styles.container}
      contentContainerStyle={styles.scrollContent} // Required for flexGrow
    >
      {/* Top Section */}
      <View style={styles.topSection}>
        <MenuItem icon="arrow-back" label="Close" onPress={() => navigation.closeDrawer()} />
        <View style={styles.divider} />
        
        <MenuItem icon="person-circle-outline" label="My Profile" onPress={() => navigation.navigate('Profile')} />
        <MenuItem icon="notifications-outline" label="Notifications" badge="3" onPress={() => navigation.navigate('Notifications')} />
        <MenuItem icon="ticket-outline" label="My Events" onPress={() => navigation.navigate('MyTickets')} />
        <MenuItem icon="settings-outline" label="Settings" onPress={() => navigation.navigate('Settings')} />
      </View>

      {/* Bottom Section (Pushed to the bottom by flexGrow) */}
      <View style={[styles.bottomSection, { paddingBottom: insets.bottom + 20 }]}>
        <View style={styles.divider} />
        <MenuItem 
          icon="log-out-outline" 
          label="Logout" 
          color={theme.colors.notification} 
          onPress={() => navigation.navigate('Login')} 
        />
      </View>
    </DrawerContentScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: theme.colors.bgSidebar,
  },
  scrollContent: {
    flexGrow: 1, // This allows the inner content to stretch to full height
    paddingTop: 20,
  },
  topSection: {
    flex: 1, // Pushes the bottom section down
  },
  bottomSection: {
    // Dynamic padding applied inline to accommodate native UI bars
  },
  menuItem: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    paddingVertical: 15, 
    paddingHorizontal: 20 
  },
  icon: { 
    marginRight: 20, 
    width: 30, 
    textAlign: 'center' 
  },
  menuText: { 
    fontSize: 16, 
    fontWeight: '500' 
  },
  divider: { 
    height: 1, 
    backgroundColor: theme.colors.borderColor, 
    marginVertical: 10 
  },
  badge: { 
    backgroundColor: theme.colors.notification, 
    borderRadius: 10, 
    paddingHorizontal: 6, 
    paddingVertical: 2, 
    marginLeft: 10 
  },
  badgeText: { 
    color: 'white', 
    fontSize: 10, 
    fontWeight: 'bold' 
  }
});