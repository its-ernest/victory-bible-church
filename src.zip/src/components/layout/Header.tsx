import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, DrawerActions } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context'; // <-- ADD THIS
import { theme } from '../../styles/theme';

export default function Header({ notificationCount = 3 }: { notificationCount?: number }) {
  const navigation = useNavigation<any>();
  const insets = useSafeAreaInsets(); // <-- ADD THIS

  return (
    <View style={[
      styles.container, 
      // Add dynamic padding and height based on the device's notch/status bar
      { paddingTop: insets.top, height: 60 + insets.top }
    ]}>
      <TouchableOpacity 
        onPress={() => navigation.dispatch(DrawerActions.openDrawer())} 
        style={styles.iconButton}
      >
        <Ionicons name="menu" size={28} color={theme.colors.textMain} />
      </TouchableOpacity>

      <View style={styles.logoContainer}>
        <Text style={styles.logoText}>V</Text>
      </View>

      <TouchableOpacity 
        style={styles.iconButton}
        onPress={() => navigation.navigate('Notifications')}
      >
        <Ionicons name="notifications-outline" size={24} color={theme.colors.textMain} />
        {notificationCount > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{notificationCount}</Text>
          </View>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  // Removed fixed height from container, it is now handled dynamically inline
  container: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, backgroundColor: theme.colors.bgHeader, borderBottomWidth: 1, borderBottomColor: theme.colors.borderColor },
  iconButton: { width: 40, alignItems: 'center', position: 'relative' },
  logoContainer: { width: 40, height: 40, borderRadius: 20, borderWidth: 1, borderColor: theme.colors.textMain, alignItems: 'center', justifyContent: 'center' },
  logoText: { color: theme.colors.textMain, fontSize: 20, fontWeight: '300' },
  badge: { position: 'absolute', top: -4, right: 2, backgroundColor: theme.colors.notification, width: 16, height: 16, borderRadius: 8, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: theme.colors.bgHeader },
  badgeText: { color: '#fff', fontSize: 8, fontWeight: 'bold' },
});