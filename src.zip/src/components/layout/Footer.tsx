import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DrawerActions } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context'; // <-- ADD THIS
import { theme } from '../../styles/theme';

export default function Footer({ state, descriptors, navigation }: any) {
  const insets = useSafeAreaInsets(); // <-- ADD THIS
  
  // Calculate dynamic bottom padding (add 10px buffer if there is an inset, otherwise 15px default)
  const bottomPadding = insets.bottom > 0 ? insets.bottom + 5 : 15;

  return (
    <View style={[
      styles.footerContainer, 
      // Apply dynamic padding and adjust height
      { paddingBottom: bottomPadding, height: 60 + bottomPadding }
    ]}>
      {state.routes.map((route: any, index: number) => {
        const { options } = descriptors[route.key];
        const isFocused = state.index === index;
        
        let iconName: any = 'home';
        if (route.name === 'Home') iconName = isFocused ? 'business' : 'business-outline';
        else if (route.name === 'News') iconName = isFocused ? 'newspaper' : 'newspaper-outline';
        else if (route.name === 'About') iconName = isFocused ? 'information-circle' : 'information-circle-outline';
        else if (route.name === 'Video') iconName = isFocused ? 'videocam' : 'videocam-outline';

        const onPress = () => {
          const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
          if (!isFocused && !event.defaultPrevented) navigation.navigate(route.name);
        };

        return (
          <TouchableOpacity key={route.name} onPress={onPress} style={styles.navItem}>
            <Ionicons name={iconName} size={22} color={isFocused ? theme.colors.textMain : theme.colors.textMuted} />
            <Text style={[styles.navText, { color: isFocused ? theme.colors.textMain : theme.colors.textMuted }]}>
              {route.name}
            </Text>
          </TouchableOpacity>
        );
      })}

      <TouchableOpacity 
        style={styles.navItem} 
        onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
      >
        <Ionicons name="menu" size={24} color={theme.colors.textMuted} />
        <Text style={styles.navText}>More</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  // Removed fixed height and paddingBottom, handled dynamically inline
  footerContainer: { backgroundColor: theme.colors.bgHeader, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', borderTopWidth: 1, borderTopColor: theme.colors.borderColor },
  navItem: { alignItems: 'center', justifyContent: 'center', width: '20%' },
  navText: { fontSize: 10, marginTop: 4, color: theme.colors.textMuted },
});