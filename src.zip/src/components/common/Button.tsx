import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../../styles/theme';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'dark' | 'outline';
  icon?: keyof typeof Ionicons.glyphMap;
  isLoading?: boolean;
  disabled?: boolean;
}

export default function Button({ 
  title, 
  onPress, 
  variant = 'primary', 
  icon, 
  isLoading = false, 
  disabled = false 
}: ButtonProps) {
  
  // Determine styles based on variant
  const isDark = variant === 'dark';
  const isOutline = variant === 'outline';
  
  const bgColor = isDark ? '#333' : isOutline ? 'transparent' : 'white';
  const textColor = isDark ? 'white' : isOutline ? 'white' : 'black';
  const borderColor = isOutline ? theme.colors.borderColor : bgColor;

  return (
    <TouchableOpacity 
      style={[
        styles.button, 
        { backgroundColor: bgColor, borderColor: borderColor },
        disabled && { opacity: 0.5 }
      ]} 
      onPress={onPress}
      activeOpacity={0.8}
      disabled={disabled || isLoading}
    >
      {isLoading ? (
        <ActivityIndicator color={textColor} />
      ) : (
        <>
          {icon && <Ionicons name={icon} size={18} color={textColor} style={styles.icon} />}
          <Text style={[styles.text, { color: textColor }]}>{title}</Text>
        </>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 14,
    borderRadius: 6,
    borderWidth: 1,
    width: '100%',
  },
  text: {
    fontWeight: 'bold',
    textTransform: 'uppercase',
    letterSpacing: 1,
    fontSize: 14,
  },
  icon: {
    marginRight: 8,
  }
});