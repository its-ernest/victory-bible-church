export const theme = {
  colors: {
    bgApp: '#000000',
    bgHeader: '#000000',
    bgSidebar: '#111111',
    bgCard: '#151515',
    bgInput: '#222222',
    textMain: '#ffffff',
    textMuted: '#888888',
    borderColor: '#222222',
    accentColor: '#4CAF50',
    notification: '#e74c3c',
  }
};