import React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { theme } from '../styles/theme';

// Import Layout Components
import Sidebar from '../components/layout/Sidebar';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';

// Import Screens
import Login from '../pages/Login';
import Home from '../pages/Home';
import Profile from '../pages/Profile';
import Notifications from '../pages/Notifications';
import Give from '../pages/Give';
import News from '../pages/News';
import About from '../pages/About';
import Video from '../pages/Video';
import Sermons from '../pages/Sermons';
import Events from '../pages/Events';
import Settings from '../pages/Settings';
import MyTickets from '../pages/MyTickets'; // <-- Final import added

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

/**
 * 1. Bottom Tabs (The Footer)
 * Hosts the primary navigation accessible from the bottom bar.
 */
function BottomTabs() {
  return (
    <Tab.Navigator
      tabBar={(props) => <Footer {...props} />}
      screenOptions={{
        header: () => <Header notificationCount={3} />,
      }}
    >
      <Tab.Screen name="Home" component={Home} />
      <Tab.Screen name="News" component={News} />
      <Tab.Screen name="About" component={About} />
      <Tab.Screen name="Video" component={Video} />
    </Tab.Navigator>
  );
}

/**
 * 2. Drawer (The Sidebar Wrapper)
 * Wraps the Tabs and provides access to secondary screens.
 */
function DrawerWrapper() {
  return (
    <Drawer.Navigator 
      drawerContent={(props: any) => <Sidebar {...props} />}
      screenOptions={{ 
        headerShown: false, 
        drawerStyle: { width: '85%' },
        drawerType: 'front' // Mimics the overlay behavior from your HTML
      }}
    >
      {/* The main tab interface */}
      <Drawer.Screen name="Tabs" component={BottomTabs} />
      
      {/* Real Screens accessed from Sidebar or Home */}
      <Drawer.Screen name="Profile" component={Profile} />
      <Drawer.Screen name="Notifications" component={Notifications} />
      <Drawer.Screen name="Give" component={Give} />
      <Drawer.Screen name="Settings" component={Settings} />
      <Drawer.Screen name="Sermons" component={Sermons} />
      <Drawer.Screen name="Events" component={Events} />
      <Drawer.Screen name="MyTickets" component={MyTickets} /> 
    </Drawer.Navigator>
  );
}

/**
 * 3. Root Stack (Auth flow -> App)
 * Switches between Login and the main application.
 */
export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="MainApp" component={DrawerWrapper} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}